#!/system/xbin/bash
clear
toilet -f slant --gay "Xbot Tools"
sleep 1
echo "\033[31;1m Website Vulnerability Scanner Grabber And Auto Exploiter"
sleep 1
echo "\033[33;1m Author: X-Mr.R4h1M"
sleep 1
echo "\033[32;1m ★contact: user.rahim@gmail.com"
sleep 1
echo "\033[34;1m ★AndroSec1337 Cyber Team"
sleep 1
echo "1. PrivTools"
echo "2. Priv AutoExploiter V1.0"
echo "3. Priv AutoExploiter V2.0"
echo "4. Priv ICGAutoExploiter V2.5"
echo "5. Priv SMTP Cracker"
echo "6. Priv Reverse ip"
echo "6. Priv cPanel Detect And Brute"
echo "7. Priv Dorker"
echo "0. Keluar"
echo "\033[30;1m00. Informasi Tool Ini"
echo "\033[33;1m Pilih Angka:"
read mrrm
if [ $mrrm = 1 ] || [ $mrrm = 1 ]
then
clear
python2 priv8.py
fi

if
[ $mrrm = 2 ] || [ $mrrm = 2 ]
then
clear
perl v1.pl
fi

if [ $mrrm = 3 ] || [ $mrrm = 3 ]
then
clear
python ICG.py 3
fi


if [ $mrrm = 4 ] || [ $mrrm = 4 ]
then
clear
toilet -f mono12 -F gay "PHD"
echo "\033[30;1m"
php 4.php
fi

if
[ $mrrm = 5 ] || [ $mrrm = 5 ]
then
clear
toilet -f mono12 -F gay "Jd.Id"
echo "\033[33;1m"
php 5.php
fi

if
[ $mrrm = 6 ] || [ $mrrm = 6 ]
then
clear
toilet -f standard -F gay "Email Bomber"
echo "\033[36;1m"
python2 6.py
fi

if
[ $mrrm = 81 ] || [ $mrrm = 81 ]
then
clear
toilet -f slant --gay "BomBer Mux"
echo "\033[31;1mNama tools: BomBer Mux"
sleep 1
echo "\033[33;1mKarya: X-Mr.R4h1M"
sleep 1
echo "\033[32;1mVersi: v1"
sleep 1
echo "\033[36;1mTeam: ★Androsec1337 Cyber Team★"
sleep 1
echo "\033[34;1mInformasi Lebih Lanjut Kunjungi: https://www.github.com/user-rahim/"
echo "\033[31;1m Spesial Thanks To: "
echo "\033[36;1m"
echo "./Xi4u7i"
echo "N07_4L0N3"
echo "Mr_/Boon'007"
echo "-xGans"
echo "X-Mr.R4h1M"
sleep 1
echo "And All Member AndroSec1337 Cyber Team"
echo "\033[30;1m tunggu 8 detik"
sleep 8
sh bom.sh
fi

if
[ $mrrm = 0 ] || [ $mrrm = 0 ]
then
echo "\033[31;1m Keluar"
sleep 1
echo "\033[32;1m Bye :)"
sleep 1
fi