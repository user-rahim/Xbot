from urllib import urlopen as o
lists = open(raw_input('list file name: '), 'r').read().split('\n')
for ip in lists:
    print 'Please Wait....'
    grab = 'null'
    try:
        grab = o('https://api.hackertarget.com/reverseiplookup/?q=' + ip).read()
        
    except:
        continue
    if 'error check' in grab:
        print 'Check format in input file And Not htpp://'
        continue
    if 'No records' in grab:
        print 'No reverse IP record available'
        continue
    grab = grab.split('\n')
    for domain in grab:
        print("[+] Found -> "+domain)
        open('Reverse.txt', 'a+').write('http://'+ domain + '\n')